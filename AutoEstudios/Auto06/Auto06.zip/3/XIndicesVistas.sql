DROP VIEW HARD14;

DROP VIEW mUniversidad ;

DROP VIEW rtaParcial;

DROP VIEW años;

DROP VIEW compPopuParciales;

DROP VIEW compPolular;

DROP VIEW compPopu;