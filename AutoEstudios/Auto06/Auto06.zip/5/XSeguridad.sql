REVOKE ALL 
    ON PA_Administrador 
FROM elAdministrador;

REVOKE ALL
    ON  PA_Musico
FROM musicos ;

REVOKE ALL
    ON  PC_Musico 
FROM musicos ;

REVOKE ALL
    ON  PC_Musico 
FROM Compositor ;

REVOKE ALL
    ON  PA_Compositor 
FROM Compositor ;