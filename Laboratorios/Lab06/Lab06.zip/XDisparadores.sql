/*XDisparadores*/


DROP TRIGGER Ad_Registros_numero_fecha;

DROP TRIGGER Ad_Registros_nomSegmento;

DROP TRIGGER Ad_Registros_nomSegmento;

DROP TRIGGER Ad_Registros_posicion;

DROP TRIGGER Md_Registros;

DROP TRIGGER Md_fotos;

DROP TRIGGER El_Registros;

DROP TRIGGER Ad_Puntos_orden ;

DROP TRIGGER Ad_Puntos_L ;

DROP TRIGGER Ad_Puntos_meta ;

DROP TRIGGER  Mo_Puntos;

DROP TRIGGER El_Puntos;

DROP TRIGGER  Ad_Carreras_cod;

DROP TRIGGER  Mo_Carreras;