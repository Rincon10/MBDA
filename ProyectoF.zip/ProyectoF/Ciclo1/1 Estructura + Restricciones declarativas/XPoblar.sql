DELETE 
FROM Empresas  ;

DELETE 
FROM PersonasNaturales ;


DELETE 
FROM CantidadInsumo;

DELETE 
FROM Insumos;

DELETE 
FROM sobreUna;

DELETE 
FROM Despachos;

DELETE 
FROM CantidadProducto;

DELETE 
FROM Compras;

DELETE 
FROM Proveedores ;

DELETE
FROM EstaEn;

DELETE 
FROM Productos;

DELETE
FROM Pedidos;

DELETE 
FROM Mesas;

DELETE
FROM Sectores;

DELETE 
FROM AccesoTiempo;

DELETE 
FROM Zonas;

DELETE 
FROM FechaLaboral;


DELETE 
FROM Labores;

DELETE
FROM Empleados;






