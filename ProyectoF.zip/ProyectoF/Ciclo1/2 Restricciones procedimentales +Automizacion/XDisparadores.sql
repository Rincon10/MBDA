/*Xdisparadores*/

DROP TRIGGER Ad_Mesas_noMesa;
DROP TRIGGER Mo_Mesas;

DROP TRIGGER Ad_Pedidos_fechaHoraini;
DROP TRIGGER Ad_Pedidos_noPedido;
DROP TRIGGER Mo_Pedido;

DROP TRIGGER Ad_Despachos_noDesp;

DROP TRIGGER Mo_AccesoTiempo;
DROP TRIGGER Mo_Empleados;

DROP TRIGGER Ad_Insumos_coInsumo;
DROP TRIGGER Mo_Insumos;

DROP TRIGGER Ad_Proveedores_tipoNit;
DROP TRIGGER Md_Proveedores;
DROP TRIGGER Md_Empresas;
DROP TRIGGER Ad_PersonasNaturales_correo;

DROP TRIGGER Ad_Compras_noCompra;
DROP TRIGGER Mo_Compras;

DROP TRIGGER Ad_Productos_coProducto;

DROP TRIGGER Ad_Zonas_noZona;

DROP TRIGGER Ad_Sectores_noSector;

DROP TRIGGER Ad_Labores_noLabor;

DROP TRIGGER EL_Pedido;