/*XSequences*/

DROP SEQUENCE Ad_noMesa;

DROP SEQUENCE Ad_noPedido;

DROP SEQUENCE Ad_noDesp;

DROP SEQUENCE Ad_coInsumo;

DROP SEQUENCE Ad_noCompra;

DROP SEQUENCE Ad_coProducto;

DROP SEQUENCE Ad_noZona;
DROP SEQUENCE Ad_noSector;

DROP SEQUENCE Ad_noLabor;