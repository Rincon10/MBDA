
/*DROP VIEW(S) */

DROP VIEW ProductosBC;

DROP VIEW ProductosCZ;

DROP VIEW MesasLibreS;

DROP VIEW empleadosCandidatos;

DROP VIEW ProveedoresPM;

/*DROP INDEX( S ) */

DROP INDEX IndFechaPedido;

DROP INDEX IndEstadoMesa;

DROP INDEX IndNombreEmpleado;

DROP INDEX IndFechaFin;