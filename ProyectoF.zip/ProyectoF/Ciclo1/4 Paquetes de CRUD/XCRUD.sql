/*XCRUD*/

DROP 
PACKAGE  PC_Mesas;


DROP 
PACKAGE  PC_Pedidos;


DROP 
PACKAGE  PC_Despachos;


DROP 
PACKAGE  PC_Empleados;


DROP 
PACKAGE  PC_Insumos;


DROP 
PACKAGE  PC_Proveedores;


DROP 
PACKAGE  PC_Compras;


DROP 
PACKAGE  PC_Productos;


DROP 
PACKAGE  PC_Zonas;


DROP 
PACKAGE  PC_Labores;


DROP 
PACKAGE PA_Mesero;


DROP 
PACKAGE PA_SupervisorDeZona;


DROP 
PACKAGE PA_GerenteDeAlimentos;

DROP 
PACKAGE PA_Administrador;