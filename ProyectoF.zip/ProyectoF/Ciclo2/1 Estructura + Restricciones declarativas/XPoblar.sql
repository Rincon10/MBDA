DELETE 
FROM fechaPatrocinio;


DELETE 
FROM Patrocinadores  ;

DELETE 
FROM Boletas;

DELETE 
FROM Zonas ;



DELETE 
FROM esAsignado;

DELETE 
FROM Tiene;

DELETE 
FROM Conciertos;

DELETE 
FROM Eventos;

DELETE 
FROM seAbasteceCon ;

DELETE
FROM Productos;

DELETE 
FROM Artistas;

DELETE
FROM Camerinos;
