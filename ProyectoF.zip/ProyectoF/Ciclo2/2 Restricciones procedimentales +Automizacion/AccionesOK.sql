/*AccionesOK*/
DELETE
FROM  Patrocinadores 
WHERE nitPatrocinador =23214856062 ;
