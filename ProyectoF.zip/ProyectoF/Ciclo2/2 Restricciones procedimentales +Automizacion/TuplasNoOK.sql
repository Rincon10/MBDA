/*Tuplas NoOk*/


