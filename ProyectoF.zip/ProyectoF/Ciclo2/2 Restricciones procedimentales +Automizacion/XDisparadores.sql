/*Xdisparadores*/

DROP TRIGGER Mod_Artistas;

DROP TRIGGER Ad_Patrocinadores_correo;
DROP TRIGGER Mod_fechaPatrocinio;

DROP TRIGGER Ad_Conciertos;
DROP TRIGGER Mod_esAsignado;
DROP TRIGGER Ad_Boletas;

DROP TRIGGER Mod_Eventos;

DROP TRIGGER Ad_Camerinos;
DROP TRIGGER Mod_Camerinos;
