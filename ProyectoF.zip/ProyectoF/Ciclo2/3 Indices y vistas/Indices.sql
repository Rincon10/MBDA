CREATE INDEX iNombreArtistico
   ON Artistas (   
               nombreArtistico 			
);
  

CREATE  INDEX  iDisponibilidad
   ON Camerinos ( 
                 disponibilidad
);
   
 
CREATE  INDEX  ifechaPatrocinio
   ON fechaPatrocinio ( 
                 Fecha
);