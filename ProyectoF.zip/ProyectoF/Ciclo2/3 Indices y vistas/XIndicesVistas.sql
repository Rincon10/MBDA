
/*DROP VIEW(S) */
DROP VIEW duoArtistas;

DROP VIEW gustosA;

DROP VIEW reporteCamerinos;

DROP VIEW InfPatro;


/*DROP INDEX( S ) */

DROP INDEX iNombreArtistico;

DROP INDEX iDisponibilidad;

DROP INDEX ifechaPatrocinio;