/*XCRUD*/

DROP 
PACKAGE  PC_Artistas;


DROP 
PACKAGE  PC_Patrocinadores;


DROP 
PACKAGE  PC_Conciertos;


DROP 
PACKAGE  PC_Eventos;


DROP 
PACKAGE  PC_Camerinos;

DROP 
PACKAGE  PA_MeseroBackstage;

DROP 
PACKAGE  PA_Director_Logistica;

DROP 
PACKAGE  PA_SupervisorZona;

